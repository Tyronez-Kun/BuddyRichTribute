# BuddyRichTribute
SoC first project pre-school
I chose Buddy Rich as the subject of the Tribute task as it was his music that inspired me to take up the drums 20 years ago.
It was a task that really put my HTML & CSS to the test. I found it rather easy to follow in the code lessons, but much harder to actually implement my own code without a tutorial, so this task really forced me to push through the barrier, looking things up and trying to apply the things i'd learned & committed to memory.

I'm really struggling to understand how to "Take your code from the Codepen challenge and insert it into the HTML and CSS files within the repository." Not sure what format it should be or where/how to do it. 
